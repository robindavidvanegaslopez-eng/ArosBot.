package com.arosbot.app;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 701;
    private TextView status;
    private MediaProjectionManager projectionManager;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 36, 28, 28);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("ArosBot — prueba inicial");
        title.setTextSize(24);
        layout.addView(title, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText("Paso 1: autoriza la captura de pantalla.\nEsta versión aún no detecta árboles ni mueve el juego.");
        status.setTextSize(16);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 24;
        layout.addView(status, sp);

        Button capture = new Button(this);
        capture.setText("Probar captura de pantalla");
        capture.setOnClickListener(v -> startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE));
        layout.addView(capture, matchWrap());

        Button accessibility = new Button(this);
        accessibility.setText("Abrir ajustes de accesibilidad");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(accessibility, matchWrap());

        Button check = new Button(this);
        check.setText("Comprobar servicio de gestos");
        check.setOnClickListener(v -> {
            boolean enabled = BotAccessibilityService.instance != null;
            status.setText(enabled ? "Servicio de accesibilidad conectado.\nAún no se envían gestos automáticamente." : "El servicio aún no está conectado. Actívalo en Accesibilidad > Servicios instalados.");
        });
        layout.addView(check, matchWrap());
        setContentView(layout);
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = 12;
        return p;
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            status.setText(resultCode == RESULT_OK
                ? "Permiso de captura concedido en esta prueba.\nEsta versión aún no procesa vídeo en vivo."
                : "Captura cancelada. Puedes volver a intentarlo.");
        }
    }
}
