# ArosBot — prototipo Android inicial

Este proyecto es un **prototipo de permisos**, no un bot completo. Incluye una pantalla de prueba para solicitar el permiso de captura de pantalla y una declaración de servicio de accesibilidad capaz de ejecutar gestos cuando se implemente y el usuario lo active.

## Construir APK

Se incluye `.github/workflows/build.yml` para compilar `app-debug.apk` mediante GitHub Actions. Sube el contenido de este proyecto a un repositorio GitHub y ejecuta el workflow `Build ArosBot APK`; luego descarga el artefacto `ArosBot-debug-apk`.

## Limitaciones actuales

- No captura ni analiza fotogramas continuamente.
- No contiene aún el detector de Pear Tree.
- No mueve el joystick ni tala automáticamente.
- El permiso de captura de pantalla es de sesión y debe concederse mediante el diálogo del sistema.
- La accesibilidad debe activarse manualmente en Ajustes y solo debe usarse con conocimiento del usuario.
