# ArosBot Android 0.4 — detección de Pear Tree

Proyecto Android/Kotlin para compilar un APK debug mediante GitHub Actions.

## Qué incluye esta versión
- Botón flotante **Probar captura de pantalla** usando `AccessibilityService.takeScreenshot()` (Android 11+).
- Botón **Iniciar detección Pear** para analizar capturas continuamente mientras el servicio siga activo.
- Selección de `pear_tree.png` desde el teléfono y persistencia del permiso de lectura.
- Búsqueda de múltiples coincidencias con varias escalas y supresión de cuadros duplicados.
- Cuadros verdes no táctiles superpuestos a las coincidencias detectadas.
- Botón para detener la detección.

## Primer uso
1. Sube el contenido de esta carpeta al repositorio GitHub (conserva `.github/workflows/build.yml`).
2. En GitHub, abre **Actions → Build ArosBot APK** y revisa el resultado de la compilación.
3. Descarga el artefacto `ArosBot-debug-apk` cuando el flujo termine correctamente.
4. Instala el APK en Android 11 o posterior.
5. Abre ArosBot y pulsa **CARGAR pear_tree.png**. Selecciona el sprite o recorte de referencia desde los archivos del teléfono.
6. Activa ArosBot en los ajustes de accesibilidad. Abre Curse of Aros y usa el panel flotante: primero **Probar captura de pantalla** y después **Iniciar detección Pear**.

## Importante
El archivo original `pear_tree.png` no estaba disponible entre los archivos a los que tuve acceso al preparar este ZIP; por eso la app permite elegirlo desde el teléfono. Sin una referencia correcta, la detección no puede identificar los árboles con fiabilidad. El detector usa comparación visual multiescala, no un modelo de IA entrenado, así que puede necesitar ajustar el recorte de referencia.

Esta versión detecta y marca visualmente; no camina ni mina de forma autónoma. La captura y la superposición requieren que el servicio de accesibilidad esté activado. Algunos juegos pueden limitar capturas o superposiciones.
