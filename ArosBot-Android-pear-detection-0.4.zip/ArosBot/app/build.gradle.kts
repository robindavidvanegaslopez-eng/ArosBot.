plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.arosbot"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.arosbot"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "0.4"
    }
}
