package com.arosbot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val pickTemplateRequest = 4102
    private val prefs by lazy { getSharedPreferences("arosbot", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
            setBackgroundColor(Color.rgb(22, 27, 35))
        }
        fun label(s: String, size: Float = 16f) = TextView(this).apply {
            text = s; textSize = size; setTextColor(Color.WHITE); setPadding(0, 7, 0, 9)
        }
        root.addView(label("🌳 ArosBot 0.4 · Pear detector", 25f))
        root.addView(label("Detección visual en vivo para Curse of Aros", 16f))
        root.addView(label(
            "1. Carga pear_tree.png una vez.\n2. Activa el servicio de accesibilidad.\n3. Abre Curse of Aros y usa el panel flotante para probar la captura o iniciar la detección continua.\n\nLa detección usa la imagen de referencia y dibuja cuadros verdes sobre las coincidencias. No mueve al personaje automáticamente.", 14f
        ))
        root.addView(Button(this).apply {
            text = "CARGAR pear_tree.png"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                startActivityForResult(intent, pickTemplateRequest)
            }
        })
        root.addView(Button(this).apply {
            text = "ABRIR ACCESIBILIDAD"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "PERMISO DE VENTANAS FLOTANTES"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else status.text = "Permiso flotante: concedido"
            }
        })
        status = label(templateStatus())
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun templateStatus(): String = if (prefs.getString("template_uri", null) != null)
        "Referencia guardada. Puedes abrir Curse of Aros y probar la detección."
    else "Falta cargar pear_tree.png desde los archivos del teléfono."

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickTemplateRequest || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            contentResolver.takePersistableUriPermission(uri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("template_uri", uri.toString()).apply()
            status.text = "pear_tree.png guardado. Abre Curse of Aros y pulsa Probar captura de pantalla."
        } catch (e: Exception) {
            status.text = "No pude guardar la referencia: ${e.message ?: "error"}"
        }
    }
}
