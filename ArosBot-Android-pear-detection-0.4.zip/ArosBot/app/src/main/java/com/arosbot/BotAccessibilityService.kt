package com.arosbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Accessibility-based screen capture and Pear Tree template matching prototype. */
class BotAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val captureExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var wm: WindowManager? = null
    private var panel: View? = null
    private var targetOverlay: TargetOverlay? = null
    private var status: TextView? = null
    private val detecting = AtomicBoolean(false)
    private var joyX = 100f
    private var joyY = 600f
    private var template: Bitmap? = null
    private var captureInFlight = AtomicBoolean(false)

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        handler.post { showPanel() }
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopDetection() }
    override fun onDestroy() {
        stopDetection(); removePanel(); hideTargetBox()
        captureExecutor.shutdownNow()
        template?.recycle(); template = null
        super.onDestroy()
    }

    private fun showPanel() {
        if (panel != null || wm == null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.argb(230, 20, 25, 33))
        }
        status = TextView(this).apply { text = "ArosBot listo"; setTextColor(Color.WHITE); textSize = 12f }
        box.addView(status)
        fun btn(text: String, action: () -> Unit) {
            box.addView(Button(this).apply { this.text = text; textSize = 11f; setOnClickListener { action() } })
        }
        btn("Probar captura de pantalla") { captureOnce() }
        btn("Iniciar detección Pear") { startDetection() }
        btn("DETENER detección") { stopDetection(); status?.text = "Detección detenida" }
        btn("Pulso arriba (prueba)") { pulse(joyX, joyY, joyX, joyY - 70f, 250) }
        btn("Ocultar panel") { removePanel() }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 10; y = 60 }
        panel = box
        try { wm?.addView(box, params) } catch (_: Exception) { panel = null }
    }

    private fun removePanel() {
        try { panel?.let { wm?.removeView(it) } } catch (_: Exception) {}
        panel = null
    }

    private fun loadTemplate(): Bitmap? {
        template?.let { if (!it.isRecycled) return it }
        val uriText = getSharedPreferences("arosbot", MODE_PRIVATE).getString("template_uri", null)
        if (uriText.isNullOrBlank()) {
            status?.text = "Primero abre ArosBot y carga pear_tree.png"
            return null
        }
        return try {
            contentResolver.openInputStream(Uri.parse(uriText)).use { input ->
                val decoded = BitmapFactory.decodeStream(input)
                if (decoded == null) {
                    status?.text = "No se pudo leer pear_tree.png"; null
                } else {
                    template = if (decoded.width > 180 || decoded.height > 180) {
                        val scale = min(180f / decoded.width, 180f / decoded.height)
                        Bitmap.createScaledBitmap(decoded, max(1, (decoded.width * scale).toInt()), max(1, (decoded.height * scale).toInt()), false).also {
                            if (it !== decoded) decoded.recycle()
                        }
                    } else decoded
                    template
                }
            }
        } catch (e: Exception) {
            status?.text = "No pude abrir pear_tree.png: ${e.message ?: "error"}"
            null
        }
    }

    private fun captureOnce() {
        if (Build.VERSION.SDK_INT < 30) { status?.text = "Captura requiere Android 11+"; return }
        if (!captureInFlight.compareAndSet(false, true)) return
        status?.text = "Probando captura y buscando Pear…"
        requestScreenshot(isContinuous = false)
    }

    private fun startDetection() {
        if (Build.VERSION.SDK_INT < 30) { status?.text = "Captura requiere Android 11+"; return }
        if (loadTemplate() == null) return
        if (detecting.compareAndSet(false, true)) {
            status?.text = "Detección en vivo iniciada…"
            requestScreenshot(isContinuous = true)
        }
    }

    private fun stopDetection() {
        detecting.set(false)
        captureInFlight.set(false)
        hideTargetBox()
    }

    private fun requestScreenshot(isContinuous: Boolean) {
        if (isContinuous && !detecting.get()) { captureInFlight.set(false); return }
        if (Build.VERSION.SDK_INT < 30) { captureInFlight.set(false); return }
        try {
            takeScreenshot(0, captureExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val buffer = screenshot.hardwareBuffer
                    var bitmap: Bitmap? = null
                    try {
                        val hardware = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                        bitmap = hardware?.copy(Bitmap.Config.ARGB_8888, false)
                        hardware?.recycle()
                        if (bitmap == null) {
                            handler.post { status?.text = "Captura recibida, no se pudo leer" }
                        } else {
                            val frame = bitmap
                            val frameWidth = frame.width
                            val frameHeight = frame.height
                            val found = matchTemplate(frame)
                            handler.post {
                                if (found.isNotEmpty()) {
                                    showTargetBoxes(found, frameWidth, frameHeight)
                                    status?.text = "${found.size} posible(s) Pear marcado(s) en verde"
                                } else {
                                    hideTargetBox()
                                    status?.text = "Captura OK, no hay coincidencias. Revisa pear_tree.png o sensibilidad."
                                }
                            }
                        }
                    } catch (e: Exception) {
                        handler.post { status?.text = "Error analizando pantalla: ${e.message ?: "desconocido"}" }
                    } finally {
                        bitmap?.recycle()
                        buffer.close()
                        captureInFlight.set(false)
                        if (isContinuous && detecting.get()) handler.postDelayed({
                            if (detecting.get()) requestScreenshot(isContinuous = true)
                        }, 650)
                    }
                }
                override fun onFailure(errorCode: Int) {
                    handler.post { status?.text = "Captura falló ($errorCode). Confirma que ArosBot tenga accesibilidad activa." }
                    captureInFlight.set(false)
                    if (isContinuous && detecting.get()) handler.postDelayed({
                        if (detecting.get()) requestScreenshot(isContinuous = true)
                    }, 1200)
                }
            })
        } catch (e: Exception) {
            captureInFlight.set(false)
            status?.text = "No se pudo iniciar captura: ${e.message ?: "error"}"
        }
    }

    /** Multi-scale RGB template match; transparent pixels in the reference are ignored. */
    private fun matchTemplate(source: Bitmap): List<Rect> {
        val ref = loadTemplate() ?: return emptyList()
        val maxWidth = 720
        val scaleDown = min(1f, maxWidth.toFloat() / source.width)
        val frame = if (scaleDown < 1f) Bitmap.createScaledBitmap(source,
            max(1, (source.width * scaleDown).toInt()), max(1, (source.height * scaleDown).toInt()), false) else source
        val sw = frame.width; val sh = frame.height
        val framePixels = IntArray(sw * sh)
        frame.getPixels(framePixels, 0, sw, 0, 0, sw, sh)
        val out = ArrayList<Pair<Rect, Float>>()
        val scales = floatArrayOf(0.68f, 0.82f, 1.0f, 1.18f, 1.36f)
        for (factor in scales) {
            val tw = max(8, (ref.width * factor).toInt())
            val th = max(8, (ref.height * factor).toInt())
            if (tw >= sw || th >= sh) continue
            val scaled = if (tw == ref.width && th == ref.height) ref else Bitmap.createScaledBitmap(ref, tw, th, false)
            val tp = IntArray(tw * th)
            scaled.getPixels(tp, 0, tw, 0, 0, tw, th)
            val sampleStep = max(1, max(tw, th) / 16)
            val samples = ArrayList<Triple<Int, Int, Int>>()
            var opaque = 0
            for (y in 0 until th step sampleStep) for (x in 0 until tw step sampleStep) {
                val c = tp[y * tw + x]
                if (Color.alpha(c) >= 70) { samples.add(Triple(x, y, c)); opaque++ }
            }
            if (scaled !== ref) scaled.recycle()
            if (opaque < 8) continue
            val xStep = max(2, tw / 4)
            val yStep = max(2, th / 4)
            for (y in 0..(sh - th) step yStep) {
                for (x in 0..(sw - tw) step xStep) {
                    var error = 0L
                    for ((tx, ty, tc) in samples) {
                        val sc = framePixels[(y + ty) * sw + x + tx]
                        error += abs(Color.red(tc) - Color.red(sc))
                        error += abs(Color.green(tc) - Color.green(sc))
                        error += abs(Color.blue(tc) - Color.blue(sc))
                    }
                    val confidence = 1f - error.toFloat() / (samples.size * 3f * 255f)
                    if (confidence >= 0.78f) {
                        val rect = Rect(
                            (x / scaleDown).toInt().coerceAtLeast(0),
                            (y / scaleDown).toInt().coerceAtLeast(0),
                            ((x + tw) / scaleDown).toInt().coerceAtMost(source.width),
                            ((y + th) / scaleDown).toInt().coerceAtMost(source.height)
                        )
                        out.add(rect to confidence)
                    }
                }
            }
        }
        if (frame !== source) frame.recycle()
        // Keep the best match first and suppress overlapping boxes from nearby scales.
        out.sortByDescending { it.second }
        val kept = ArrayList<Rect>()
        for ((r, _) in out) {
            val duplicate = kept.any { k ->
                val ix = max(0, min(r.right, k.right) - max(r.left, k.left))
                val iy = max(0, min(r.bottom, k.bottom) - max(r.top, k.top))
                val intersection = ix.toLong() * iy
                val union = r.width().toLong() * r.height() + k.width().toLong() * k.height() - intersection
                union > 0 && intersection.toFloat() / union > 0.28f
            }
            if (!duplicate) kept.add(Rect(r))
            if (kept.size >= 25) break
        }
        return kept
    }

    private fun showTargetBoxes(rects: List<Rect>, imageW: Int, imageH: Int) {
        handler.post {
            val overlay = targetOverlay ?: TargetOverlay().also { targetOverlay = it }
            overlay.setTargets(rects, imageW, imageH)
            if (overlay.parent == null) {
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.TOP or Gravity.START }
                try { wm?.addView(overlay, params) } catch (_: Exception) { targetOverlay = null }
            }
        }
    }

    private fun hideTargetBox() {
        handler.post {
            try { targetOverlay?.let { if (it.parent != null) wm?.removeView(it) } } catch (_: Exception) {}
            targetOverlay = null
        }
    }

    private inner class TargetOverlay : View(this@BotAccessibilityService) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var targets: List<Rect> = emptyList()
        private var imageW = 1
        private var imageH = 1
        fun setTargets(rects: List<Rect>, w: Int, h: Int) { targets = rects; imageW = w.coerceAtLeast(1); imageH = h.coerceAtLeast(1); invalidate() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val sx = width.toFloat() / imageW
            val sy = height.toFloat() / imageH
            paint.color = Color.GREEN; paint.style = Paint.Style.STROKE; paint.strokeWidth = 5f
            for ((i, r) in targets.withIndex()) {
                val box = RectF(r.left * sx, r.top * sy, r.right * sx, r.bottom * sy)
                canvas.drawRoundRect(box, 7f, 7f, paint)
                paint.style = Paint.Style.FILL; paint.textSize = 25f; paint.setShadowLayer(4f, 1f, 1f, Color.BLACK)
                canvas.drawText("PEAR ${i + 1}", box.left, (box.top - 5f).coerceAtLeast(25f), paint)
                paint.clearShadowLayer(); paint.style = Paint.Style.STROKE
            }
        }
    }

    private fun pulse(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long) {
        if (Build.VERSION.SDK_INT < 24) { status?.text = "Gestos requieren Android 7+"; return }
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { status?.text = "Pulso enviado (prueba)" }
            override fun onCancelled(gestureDescription: GestureDescription?) { status?.text = "Gesto cancelado" }
        }, handler)
    }
}
