El sprite pear_tree.png no estaba entre los archivos accesibles al generar este paquete.
Abre ArosBot en el teléfono y usa el botón CARGAR pear_tree.png para seleccionar la imagen de referencia.
La app guarda el permiso de lectura y la reutiliza para la detección en vivo.
